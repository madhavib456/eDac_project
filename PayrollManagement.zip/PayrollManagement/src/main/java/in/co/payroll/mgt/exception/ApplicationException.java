package in.co.payroll.mgt.exception;


public class ApplicationException extends Exception {

    /**
     *             Error message
     */
    public ApplicationException(String msg) {
        super(msg);
    }
}