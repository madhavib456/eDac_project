package in.co.payroll.mgt.exception;

public class DatabaseException  extends Exception
{
	/**
    *  Error message
    */
   public DatabaseException(String msg) {
       super(msg);
   }
}

