package in.co.payroll.mgt.exception;

/**
 * DuplicateRecordException thrown when a duplicate record occurred
 */
public class DuplicateRecordException  extends Exception
{
	/**
	 *            error message
	 */
	public DuplicateRecordException(String msg) {
		super(msg);
	}
}
