package in.co.payroll.mgt.dao;

import java.util.List;
import java.util.Map;
import java.util.Set;

import in.co.payroll.mgt.dto.AttendanceDTO;


public interface AttendanceDAOInt {
	
	/**
	 * Adds a Role.
	 * @return pk of dto
	 */
	public long add(AttendanceDTO dto);

	/**
	 * Update a Role.
	 */
	public void update(AttendanceDTO dto);

	/**
	 * Delete a Role.
	 */
	public void delete(AttendanceDTO dto);
	

    /**
     * Find Role by Name
     * 
     * get parameter
     * @return dto
     
     */
	public AttendanceDTO findByName(String name);
	

	/**
	 * Find a Role by it's pk.
	 * @return RoleDTO
	 */
	public AttendanceDTO findByPk(long id);

	/**
	 * Search Roles with pagination.
	 * @return List
	 */
	public List<AttendanceDTO> search(AttendanceDTO dto, long pageNo, int pageSize);

	/**
	 * Search Roles.
	 * @return List
	 */
	public List<AttendanceDTO> search(AttendanceDTO dto);
	
	
	/**
	 * Get map of id v/s it's dto, key is id and value is dto
	 * @return Map
	 */
	public Map<Long, AttendanceDTO> getMapDTO(Set<Long> ids);

}
